type SteamAppDetailsResponse = {
    data: SteamGameDetails
};
