type SteamGameGenre = {
    id: string,
    description: string
}
