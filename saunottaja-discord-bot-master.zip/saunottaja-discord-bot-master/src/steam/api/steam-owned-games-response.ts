type SteamOwnedGamesResponse = {
    response: SteamOwnedGames
};
