type SteamOwnedGames = {
    game_count: number,
    games: SteamGame[]
}
