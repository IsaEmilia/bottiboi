type SteamGameCategory = {
    id: number,
    description: string
}
