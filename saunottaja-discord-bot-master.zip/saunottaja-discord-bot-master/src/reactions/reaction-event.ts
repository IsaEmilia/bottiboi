export enum ReactionEvent {
    messageReactionAdd = "messageReactionAdd",
    messageReactionRemove = "messageReactionRemove"
}
