export default class MessagePagePosition {
    constructor(
        public discordMessageId: string,
        public currentPageIndex: number
    ) {}
}
